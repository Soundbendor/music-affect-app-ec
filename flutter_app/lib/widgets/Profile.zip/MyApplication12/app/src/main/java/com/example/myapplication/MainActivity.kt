package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONException
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL


class MainActivity : AppCompatActivity() {
    var user: EditText? = null
    var email: EditText? = null
    var fname: EditText? = null
    var lname: EditText? = null
    var user1: String? = null
    var email1: String? = null
    var fname1: String? = null
    var lname1: String? = null
    var reply: String? = null
    var code: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        user = findViewById(R.id.user1)
        email = findViewById(R.id.email1)
        fname = findViewById(R.id.fname)
        lname = findViewById(R.id.lname)
        user1 = ""
        email1 = ""
        fname1 = ""
        lname1 = ""

        val button=findViewById<Button>(R.id.btnStartAnotherActivity)
        button.setOnClickListener{
            val Intent=Intent(this, MainActivity2::class.java )
            startActivity(Intent)
        }
    }

    fun create(view: View?) {
        user1 = user!!.text.toString()
        email1 = email!!.text.toString()
        fname1 = fname!!.text.toString()
        lname1 = lname!!.text.toString()
        if (user1!!.isEmpty() || email1!!.isEmpty() || fname1!!.isEmpty() || lname1!!.isEmpty()) {
            Toast.makeText(this@MainActivity, "Fields cannot be blank", Toast.LENGTH_SHORT)
                .show() // Check whether the fields are not blank
        } else {
            // Create various messages to display in the app.
            val failed_toast =
                Toast.makeText(this@MainActivity, "Request failed", Toast.LENGTH_SHORT)
            val created_toast =
                Toast.makeText(this@MainActivity, "User created", Toast.LENGTH_SHORT)
            // Create a worker thread for sending HTTP requests.
            val thread = Thread {
                try {
                    val url = URL("http://138.68.64.95:8080/api/user/add") // new url object is created
                    val conn =
                        url.openConnection() as HttpURLConnection // HTTP connection object is created
                    conn.requestMethod = "POST" // POST method
                    conn.setRequestProperty(
                        "Content-Type",
                        "application/json; utf-8"
                    ) // JSON format is specified
                    conn.setRequestProperty("Accept", "application/json")
                    conn.doOutput = true
                    conn.doInput = true
                    val input = JSONObject() // New JSON object is created
                    // Give data to the json object
                    input.put("username", user1)
                    input.put("email", email1)
                    input.put("firstName", fname1)
                    input.put("lastName", lname1)
                    val os =
                        DataOutputStream(conn.outputStream) // Output stream object for HTTP connection is created
                    os.writeBytes(input.toString()) // JSON object is serialized and sent over the HTTP connection to the listening server
                    os.flush() // Flushing the output buffers
                    os.close() // Closing the output stream
                    val `is` =
                        conn.inputStream // Input stream object for HTTP connection is created
                    val sb = StringBuffer() // String buffer object is created
                    // Fetch and append the incoming bytes until no more comes over the input stream.
                    try {
                        var chr: Int
                        while (`is`.read().also { chr = it } != -1) {
                            sb.append(chr.toChar())
                        }
                        reply = sb.toString()
                    } finally {
                        `is`.close() // Closing the input stream
                    }
                    code = conn.responseCode.toString() // Get the HTTP status code
                    conn.disconnect() // Disconnecting
                    Log.i("Code", code!!)
                    // For unreachable network or other network related failures.
                    if (code != "201") {
                        failed_toast.show()
                    } else {
                        created_toast.show()
                    }
                } catch (e: MalformedURLException) {
                    e.printStackTrace()
                    failed_toast.show()
                } catch (e: IOException) {
                    e.printStackTrace()
                    failed_toast.show()
                } catch (e: JSONException) {
                    e.printStackTrace()
                    failed_toast.show()
                }
            }
            thread.start()
        }
    }

    fun user(view: View?) {
        val user = Intent(this@MainActivity, User::class.java)
        startActivity(user)
    }
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.spotify.com"))
    override fun startActivity(intent: Intent?) {
        super.startActivity(intent)
    }
}
